import{ar as a}from"../chunks/Bbu00C9R.js";export{a as component};
